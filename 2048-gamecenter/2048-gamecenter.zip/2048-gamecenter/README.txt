README: Comp 20 Assignment #4, 10 April 2014
George Brown

The 3 features specified have been implemented:
1) POST /submit.json -- no known bugs: submits game info
2) GET /scores.json -- no known bugs: returns JSON string for a user
3) GET / -- no known bugs: displays all players' scores

As far as I know, everything in the assignment has been implemented correctly.

I have also implemented a fourth page, /game, that allows a user to play the
game and then enter a username to submit a score. Except for the POST request,
the game is all Gabriele Cirulli's code.

I spent a lot of time early on with this assignment, so I helped a number of
people, some of whom I also received help from. I collaborated with Max Cohen,
Siddhartha Prasad, Skyler Tom, and Victor Chao. I also helped Aansh Kapadia
early on.

I spent about 15 hours, a lot of it at the beginning trying to understand how
the MVC worked. Nate Tarrh helped me a lot, and Jasper's Mongo session and code
helped me get started as well.

The score and grid are stored in Javascript objects. The GameManager
object is what holds these objects; referencing this.grid refers to the grid in
the current GameManager object -- same with score. A Grid is itself a separate 
object, as defined in grid.js.

I modified game_manager.js by adding (using jquery) an AJAX POST request when a
game ends. This sends the score, grid (stringified), and username to my
database via the submit.json API. I added jQuery to the index.html file from the
original game.

I cleaned up most of the extra files, but left some Jade files in views. I
experimented a lot with Jade last but found it easier to use the hacky HTML way
of rendering the necessary information.

Security was not considered at all, and user input is not sanitized at all.
