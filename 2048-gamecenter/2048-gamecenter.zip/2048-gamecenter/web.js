//web.js -- by George Brown

var express = require("express");
var logfmt = require("logfmt");
var routes = require("./routes/routes");
var http = require("http");
var path = require ("path");
var mongo = require("mongodb");

var app = express();

var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL ||
        "mongodb://localhost/scorecenter";

var db = mongo.Db.connect(mongoUri, function (err, database) {
      db = database;
});

// environments
app.set("port", process.env.PORT || 3000);
app.use(logfmt.requestLogger());
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "jade");
app.use(express.logger("dev"));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, "public")));
app.use("/style.css", express.static(__dirname + '/style.css'));
app.use("/index.html", express.static(__dirname + "/index.html"));

// development only
if ("development" == app.get("env")) {
  app.use(express.errorHandler());
}

//root: prints a list of users and scores
app.get('/', function(req,res) {
  res.set("Content-Type", "text/html");
  var htmlToRender = '<!DOCTYPE HTML><html><head><link href="/style.css" media="all" rel="stylesheet" type="text/css" /><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"/></head><body><h1>2048 Scorecenter</h1><br><h2>George Brown, April 2014</h2><br><h2><a href="/game">Play Game!</a></h2><table id="mytable"><thead><tr><th>Score</th><th>User</th><th>Time</th></tr></thead><tbody>';
  db.collection("scores", function(er, col) {
    if (!er) {
      col.find().sort({score:-1}).toArray(function(errr,goodthing){
        // Add all scores to the table, in descending order
        for (var i = 0; i < goodthing.length; i++) {
          htmlToRender += "<tr><td>";
          htmlToRender += goodthing[i].score;
          htmlToRender += "</td><td>";
          htmlToRender += goodthing[i].username;
          htmlToRender += "</td><td>";
          htmlToRender += goodthing[i].created_at;
          htmlToRender += "</td></tr>";
        }
        htmlToRender += "</tbody></table></body></html>"
        res.send(htmlToRender);
        });
  }
  });
});

//game: allows people to play the game
app.get('/game', function(req, res) {
  res.sendfile(path.join(__dirname, 'public', path.basename("index.html")));
});

//scores.json: open API for people to get scores by user
app.get('/scores.json', function(req, res) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  var usr = req.query.username;
  if(usr == undefined || usr === undefined) {
    res.send("[]");
  } else {
    db.collection("scores", function(er, col) {
      col.find({username:usr}).sort({score:-1}).toArray(function(e, goodthing){
        res.send(goodthing);
      });
    });
  }
});

//submit.json: 
app.post('/submit.json', function(req, res) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    db.collection("scores", function (er, collection){
      if(req.body.score && req.body.username && req.body.grid) {
        var tempScore = req.body.score;
        var score = parseInt(tempScore, 10);
        var username = req.body.username;
        var grid = req.body.grid;
        var currTime = new Date().toUTCString();
        collection.insert({"score": score, "username": username, "grid": grid, "created_at":currTime}, function (err, r){});
      } else {
        console.log("Error: Not all fields specified in post request. Required: score, username, grid)");
      }  
    });
  });


http.createServer(app).listen(app.get("port"), function(){
  console.log("Express server listening on port " + app.get("port"));
});
