exports.index = function() {
  res.render("index");
};

exports.game = function(req, res) {
  console.log("hello");
  res.render('game');
};